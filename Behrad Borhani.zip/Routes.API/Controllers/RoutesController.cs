﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Routes.Model;
using System.Text.RegularExpressions;

namespace Routes.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RoutesController : ControllerBase
    {
        private List<Airline> airlinesList;
        private List<Airport> airportList;
        private List<Route> routeList;

        private List<string> shortestPath = new List<string>();
        private string finalDestination;

        public RoutesController()
        {
            InitializeData();
        }

        /**
         * Fetch data from CSV files
         */
        private void InitializeData()
        {
            #region Airlines data
            Regex CSVParser = new Regex(",(?=(?:[^\"]*\"[^\"]*\")*(?![^\"]*\"))");
            string[] airlines = System.IO.File.ReadAllLines(@"../Data/airlines.csv");
            IEnumerable<Airline> airlinesEnumerable =
                from al in airlines.Skip(1)
                let splitAirlines = CSVParser.Split(al)
                select new Airline()
                {
                    Name = splitAirlines[0],
                    TwoDigitCode = splitAirlines[1],
                    ThreeDigitCode = splitAirlines[2],
                    Country = splitAirlines[3]
                };
            this.airlinesList = airlinesEnumerable.ToList();
            #endregion

            #region Airport data 
            string[] airports = System.IO.File.ReadAllLines(@"../Data/airports.csv");
            IEnumerable<Airport> airportsEnumerable =
                from ap in airports.Skip(1)
                let splitAirports = CSVParser.Split(ap)
                select new Airport()
                {
                    Name = splitAirports[0],
                    City = splitAirports[1],
                    Country = splitAirports[2],
                    IATA3 = splitAirports[3],
                    Latitute = Double.Parse(splitAirports[4].ToString()),
                    Longitude = Double.Parse(splitAirports[5].ToString())
                };
            this.airportList = airportsEnumerable.ToList();
            #endregion

            #region Routes data
            string[] routes = System.IO.File.ReadAllLines(@"../Data/routes.csv");
            IEnumerable<Route> routesEnumerable =
                from ap in routes.Skip(1)
                let splitAirports = CSVParser.Split(ap)
                select new Route()
                {
                    AirlineId = splitAirports[0],
                    Origin = splitAirports[1],
                    Destination = splitAirports[2]
                };
            this.routeList = routesEnumerable.ToList();
            #endregion
        }

        // GET api/routes/FindRoutes/5
        [HttpGet("FindRoutes/{origin}/{destination}")]
        public ActionResult<string> FindRoutes(string origin, string destination)
        {
            try
            {
                // Check Origin
                var originExists = this.airportList.Any(x => x.IATA3.Equals(origin));
                if (!originExists)
                {
                    return "Invalid Origin";
                }

                // Check Destination
                var destinationExists = this.airportList.Any(x => x.IATA3.Equals(destination));
                if (!destinationExists)
                {
                    return "Invalid Destination";
                }

                this.finalDestination = destination;
                this.findShortestConnection(origin, destination);

                this.shortestPath.Reverse();
                this.shortestPath.Add(destination);

                return string.Join("->", this.shortestPath);
            }
            catch (Exception ex)
            {
                BadRequest(ex.Message);
                return "There was an error generating this request. Please check server logs.";
            }
        }

        private bool findShortestConnection(string origin, string destination)
        {
            string current = destination;
            if (current.Equals(origin))
            {
                return true;
            }
            else
            {
                // There may be a direct flight!
                var directFlight = this.routeList.Where(route => route.Destination.Equals(destination) && route.Origin.Equals(origin)).ToList().FirstOrDefault();
                if (directFlight != null)
                {
                    this.shortestPath.Add(directFlight.Origin);
                    return true;
                }
                // ok there isn't so pick any connecting flight
                var someDestination = this.routeList.Where(route => route.Destination.Equals(destination) && route.Origin != this.finalDestination).ToList().FirstOrDefault();
                this.shortestPath.Add(someDestination.Origin);
                this.findShortestConnection(origin, someDestination.Origin);
            }

            return false;
        }
    }
}
