﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Routes.Model
{
    public class Airport
    {
        //Name	City	Country	IATA 3	Latitute	Longitude
        public string Name { get; set; }
        public string City { get; set; }
        public string Country { get; set; }
        public string IATA3 { get; set; }
        public double Latitute { get; set; }
        public double Longitude { get; set; }
    }
}
