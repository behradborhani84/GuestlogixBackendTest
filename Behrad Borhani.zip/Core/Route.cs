﻿using System;

namespace Routes.Model
{
    public class Route
    {
        public string AirlineId { get; set; }
        public string Origin { get; set; }
        public string Destination { get; set; }
        public decimal Distance { get; set; }
    }
}
