﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Routes.Model
{
    public class Airline
    {
        public string Name { get; set; }
        public string TwoDigitCode { get; set; }
        public string ThreeDigitCode { get; set; }
        public string Country { get; set; }
    }
}
